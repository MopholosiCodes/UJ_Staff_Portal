﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public class DataLayer
    {
        public List<string> Users = new List<string>();
        public string FirstName;
        public string LastName;
        public string Email;
        public int Age;

        public DataLayer(string firstname, string lastname, string email, int age)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.Email = email;
            this.Age = age;

            // store data in list
            var status = $"{FirstName} {LastName} {Email} {Age}";
            Users.Append(status);
        }

        public void StoreData()
        {

        }
    }
}
